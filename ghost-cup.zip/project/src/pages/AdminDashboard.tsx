import { useEffect, useState } from 'react';
import { Users, Users2, Swords, Clock, ChevronRight, RefreshCw, CheckCircle, AlertCircle, UserPlus, Calendar } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Match, ActivityLog, Page } from '../types';

interface AdminDashboardProps {
  onNavigate: (page: Page, data?: unknown) => void;
}

interface DashboardStats {
  players: number;
  teams: number;
  matchesPlayed: number;
  matchesPending: number;
}

function StatCard({ icon, label, value, color }: { icon: React.ReactNode; label: string; value: number | string; color: string }) {
  return (
    <div className="card p-6">
      <div className="flex items-start justify-between">
        <div>
          <p className={`font-barlow font-black text-4xl leading-none mb-2 ${color}`}>{value}</p>
          <p className="text-ghost-gray text-xs font-barlow uppercase tracking-widest">{label}</p>
        </div>
        <span className={`${color} opacity-40`}>{icon}</span>
      </div>
    </div>
  );
}

const ACTIVITY_ICONS: Record<string, React.ReactNode> = {
  score_validated: <CheckCircle size={14} className="text-ghost-green" />,
  new_player: <UserPlus size={14} className="text-ghost-gold" />,
  match_scheduled: <Calendar size={14} className="text-white" />,
  proof_submitted: <AlertCircle size={14} className="text-ghost-gold" />,
};

export default function AdminDashboard({ onNavigate }: AdminDashboardProps) {
  const [stats, setStats] = useState<DashboardStats>({ players: 0, teams: 0, matchesPlayed: 0, matchesPending: 0 });
  const [recentActivity, setRecentActivity] = useState<ActivityLog[]>([]);
  const [_activeBracketMatches, setActiveBracketMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);

    // Stats
    const [
      { count: playerCount },
      { count: teamCount },
      { count: playedCount },
      { count: pendingCount },
    ] = await Promise.all([
      supabase.from('profiles').select('*', { count: 'exact', head: true }).eq('role', 'player'),
      supabase.from('teams').select('*', { count: 'exact', head: true }),
      supabase.from('matches').select('*', { count: 'exact', head: true }).eq('status', 'completed'),
      supabase.from('matches').select('*', { count: 'exact', head: true }).in('status', ['scheduled', 'live']),
    ]);

    setStats({
      players: playerCount ?? 0,
      teams: teamCount ?? 0,
      matchesPlayed: playedCount ?? 0,
      matchesPending: pendingCount ?? 0,
    });

    // Activity logs
    const { data: logs } = await supabase
      .from('activity_logs')
      .select('*, admin:profiles(cod_username)')
      .order('created_at', { ascending: false })
      .limit(8);
    setRecentActivity((logs as ActivityLog[]) ?? []);

    // Active bracket matches
    const { data: activeMatches } = await supabase
      .from('matches')
      .select('*')
      .in('status', ['live', 'scheduled'])
      .order('round_order', { ascending: false })
      .limit(4);
    setActiveBracketMatches((activeMatches as Match[]) ?? []);

    setLoading(false);
  }

  // Demo activity data when no real logs exist
  const demoActivity = [
    { id: '1', action: 'score_validated', details: { desc: 'Wild Squad vs Team Legend — 5v5 2/4 Finale' }, created_at: new Date().toISOString(), admin_id: undefined },
    { id: '2', action: 'new_player', details: { desc: 'Nouveau joueur inscrit : Player_2025' }, created_at: new Date(Date.now() - 3600000).toISOString(), admin_id: undefined },
    { id: '3', action: 'match_scheduled', details: { desc: 'Match programmé : Ghost Unit vs Rapid Fire' }, created_at: new Date(Date.now() - 7200000).toISOString(), admin_id: undefined },
    { id: '4', action: 'proof_submitted', details: { desc: 'Preuve de score envoyée : Ghost Unit vs Black Ops' }, created_at: new Date(Date.now() - 10800000).toISOString(), admin_id: undefined },
  ];

  const activity = recentActivity.length > 0 ? recentActivity : (demoActivity as ActivityLog[]);

  function formatTime(d: string) {
    const diff = Date.now() - new Date(d).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `il y a ${mins} min`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `il y a ${hrs}h`;
    return new Date(d).toLocaleDateString('fr-FR');
  }

  return (
    <div className="animate-slide-up">
      <div className="flex items-center justify-between mb-8 flex-wrap gap-4">
        <div>
          <p className="section-title">GHOST CUP ADMIN</p>
          <h1 className="font-barlow font-black text-3xl text-white uppercase">TABLEAU DE BORD</h1>
        </div>
        <button onClick={load} disabled={loading} className="btn-outline text-xs py-2 px-4 flex items-center gap-2">
          <RefreshCw size={12} className={loading ? 'animate-spin' : ''} /> ACTUALISER
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard icon={<Users size={28} />} label="Joueurs inscrits" value={stats.players || 128} color="text-white" />
        <StatCard icon={<Users2 size={28} />} label="Équipes (5VS5)" value={stats.teams || 32} color="text-ghost-gold" />
        <StatCard icon={<Swords size={28} />} label="Matchs joués" value={stats.matchesPlayed || 24} color="text-ghost-green" />
        <StatCard icon={<Clock size={28} />} label="En attente" value={stats.matchesPending || 6} color="text-ghost-red" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Activity */}
        <div className="lg:col-span-2">
          <p className="section-title mb-4">ACTIVITÉ RÉCENTE</p>
          <div className="space-y-2">
            {activity.map(log => (
              <div key={log.id} className="card px-4 py-3 flex items-start gap-3">
                <div className="mt-0.5 shrink-0">
                  {ACTIVITY_ICONS[log.action] ?? <Clock size={14} className="text-ghost-gray" />}
                </div>
                <div className="flex-1">
                  <p className="text-white text-xs font-barlow font-bold">
                    {(log.details as Record<string, string>)?.desc ?? log.action}
                  </p>
                  <p className="text-ghost-gray text-[10px] mt-0.5">{formatTime(log.created_at)}</p>
                </div>
                <span className={`text-[9px] font-barlow font-bold uppercase px-2 py-0.5 border ${
                  log.action === 'score_validated' ? 'text-ghost-green border-ghost-green/40' :
                  log.action === 'new_player' ? 'text-ghost-gold border-ghost-gold/40' :
                  'text-ghost-gray border-ghost-border'
                }`}>
                  {log.action === 'score_validated' ? '5v5' :
                   log.action === 'new_player' ? '1v1' : '5v5'}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Brackets */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <p className="section-title">BRACKETS EN COURS</p>
          </div>

          {/* 5v5 bracket summary */}
          <div className="card p-4 mb-3 hover:border-ghost-gold/20 transition-all cursor-pointer" onClick={() => onNavigate('admin-brackets')}>
            <div className="flex items-center justify-between mb-2">
              <span className="font-barlow font-black text-ghost-gold text-xs uppercase tracking-wider">5 VS 5</span>
              <span className="text-ghost-gray text-[10px] font-barlow">1/2 FINALE</span>
            </div>
            <div className="space-y-1.5">
              {['Daydordan0', 'Cloudgamers'].map((t, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-ghost-green" />
                  <span className="text-white text-xs font-barlow">{t}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="card p-4 mb-4 hover:border-ghost-gold/20 transition-all cursor-pointer" onClick={() => onNavigate('admin-brackets')}>
            <div className="flex items-center justify-between mb-2">
              <span className="font-barlow font-black text-ghost-gold text-xs uppercase tracking-wider">1 VS 1</span>
              <span className="text-ghost-gray text-[10px] font-barlow">1/4 FINALE</span>
            </div>
            <div className="space-y-1.5">
              {['Ghost_Alpha', 'Dark_Knight'].map((t, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-ghost-gold" />
                  <span className="text-white text-xs font-barlow">{t}</span>
                </div>
              ))}
            </div>
          </div>

          <button onClick={() => onNavigate('admin-brackets')} className="btn-gold w-full text-xs py-2.5 flex items-center justify-center gap-2">
            VOIR LES BRACKETS <ChevronRight size={12} />
          </button>
        </div>
      </div>

      {/* Quick actions */}
      <div className="mt-8">
        <p className="section-title mb-4">ACTIONS RAPIDES</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: 'Gérer les matchs', page: 'admin-matchs' as Page, color: 'btn-gold' },
            { label: 'Joueurs & Équipes', page: 'admin-joueurs' as Page, color: 'btn-dark' },
            { label: 'Brackets', page: 'admin-brackets' as Page, color: 'btn-dark' },
            { label: 'Annonces', page: 'admin-annonces' as Page, color: 'btn-dark' },
          ].map(({ label, page, color }) => (
            <button key={page} onClick={() => onNavigate(page)} className={`${color} text-xs py-3 w-full`}>
              {label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
