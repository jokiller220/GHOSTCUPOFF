import { useEffect, useState } from 'react';
import { RefreshCw, GitBranch } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Match, Format, Page } from '../types';
import BracketTree from '../components/BracketTree';

interface AdminBracketsPageProps {
  onNavigate: (page: Page, data?: unknown) => void;
}

export default function AdminBracketsPage({ onNavigate }: AdminBracketsPageProps) {
  const [format, setFormat] = useState<Format>('5v5');
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const { data } = await supabase
      .from('matches')
      .select('*, scores:match_scores(*)')
      .eq('format', format)
      .order('round_order')
      .order('match_order');
    setMatches((data as Match[]) ?? []);
    setLoading(false);
  }

  useEffect(() => { load(); }, [format]);

  return (
    <div className="animate-slide-up">
      <div className="flex items-center justify-between mb-8 flex-wrap gap-4">
        <div>
          <p className="section-title">ADMIN</p>
          <h1 className="font-barlow font-black text-3xl text-white uppercase">BRACKETS</h1>
        </div>
        <button onClick={load} className="btn-outline text-xs py-2 px-4 flex items-center gap-2">
          <RefreshCw size={12} /> ACTUALISER
        </button>
      </div>

      {/* Format tabs */}
      <div className="flex border-b border-ghost-border mb-6">
        {(['5v5', '1v1'] as Format[]).map(f => (
          <button
            key={f}
            onClick={() => setFormat(f)}
            className={`px-8 py-3 font-barlow font-black text-xs uppercase tracking-widest border-b-2 transition-all ${
              format === f ? 'text-ghost-gold border-ghost-gold' : 'text-ghost-gray border-transparent hover:text-white'
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-48 gap-3 text-ghost-gray">
          <RefreshCw size={16} className="animate-spin" />
        </div>
      ) : matches.length === 0 ? (
        <div className="card p-12 text-center">
          <GitBranch size={32} className="mx-auto mb-3 text-ghost-gray/30" />
          <p className="font-barlow text-ghost-gray text-sm uppercase tracking-wider mb-4">Aucun bracket généré</p>
        </div>
      ) : (
        <div className="card p-6 overflow-hidden">
          <BracketTree
            matches={matches}
            onMatchClick={m => onNavigate('admin-match-detail', m.id)}
          />
        </div>
      )}
    </div>
  );
}
