import { Shield, Target, Scale, AlertTriangle, ChevronDown, ChevronUp } from 'lucide-react';
import { useState } from 'react';

const sections = [
  {
    icon: <Target size={18} />,
    id: 'modes',
    title: 'MODES DE JEU (5VS5)',
    content: [
      { heading: '', items: ['Hardpoint', 'Search and Destroy (SND)', 'Contrôle'] },
    ],
  },
  {
    icon: <Shield size={18} />,
    id: 'format',
    title: 'FORMAT',
    content: [
      {
        heading: '',
        items: [
          'Toutes les rencontres se jouent en BO5.',
          'La première équipe à remporter 3 manches gagne le match.',
          'Les 1v1 se jouent en mode SND, BO5.',
        ],
      },
    ],
  },
  {
    icon: <Scale size={18} />,
    id: 'egalite',
    title: "RÈGLES D'ÉGALITÉ",
    content: [
      {
        heading: '',
        items: [
          "En cas d'égalité 2:2, la dernière manche est décisive.",
          "En cas de problème technique, le match peut être rejoué.",
          "Un forfait est déclaré après 15 minutes d'attente sans notification.",
        ],
      },
    ],
  },
  {
    icon: <AlertTriangle size={18} />,
    id: 'fairplay',
    title: 'FAIR-PLAY',
    content: [
      {
        heading: '',
        items: [
          'Respect des adversaires et des administrateurs.',
          'Aucune forme de triche ou hack tolérée.',
          "Toute infraction peut entraîner une disqualification.",
          'Les preuves de score (screenshot/clip) sont obligatoires.',
          'Les décisions des admins sont définitives et sans appel.',
        ],
      },
    ],
  },
];

function Section({ section, expanded, onToggle }: {
  section: typeof sections[0];
  expanded: boolean;
  onToggle: () => void;
}) {
  return (
    <div className={`card border transition-all duration-300 ${expanded ? 'border-ghost-gold/30' : 'border-ghost-border hover:border-ghost-border/80'}`}>
      <button
        className="w-full flex items-center justify-between px-6 py-4 text-left"
        onClick={onToggle}
      >
        <div className="flex items-center gap-3">
          <span className={`transition-colors duration-200 ${expanded ? 'text-ghost-gold' : 'text-ghost-gray'}`}>
            {section.icon}
          </span>
          <span className={`font-barlow font-black text-sm uppercase tracking-widest transition-colors duration-200 ${expanded ? 'text-ghost-gold' : 'text-white'}`}>
            {section.title}
          </span>
        </div>
        <span className="text-ghost-gray">
          {expanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </span>
      </button>

      {expanded && (
        <div className="px-6 pb-6 border-t border-ghost-border/30 pt-4 animate-fade-in">
          {section.content.map((block, i) => (
            <div key={i} className="mb-4">
              {block.heading && (
                <p className="font-barlow font-bold text-ghost-gold text-xs uppercase tracking-widest mb-3">
                  {block.heading}
                </p>
              )}
              <ul className="space-y-2">
                {block.items.map((item, j) => (
                  <li key={j} className="flex items-start gap-3 text-ghost-gray-light text-sm">
                    <span className="w-1 h-1 rounded-full bg-ghost-gold mt-2 shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function Reglement() {
  const [expanded, setExpanded] = useState<string>('modes');

  return (
    <div className="max-w-3xl mx-auto px-6 py-12 animate-slide-up">
      {/* Header */}
      <div className="text-center mb-12">
        <p className="section-title text-center">GHOST CUP</p>
        <h1 className="font-barlow font-black text-4xl md:text-5xl text-white uppercase mb-4">
          RÈGLEMENT<br />
          <span className="text-ghost-gold">DU TOURNOI</span>
        </h1>
        <div className="gold-divider" />
        <p className="text-ghost-gray text-sm max-w-md mx-auto mt-4">
          La participation implique l'acceptation complète et sans réserve de ce règlement.
        </p>
      </div>

      {/* Sections */}
      <div className="space-y-3">
        {sections.map(section => (
          <Section
            key={section.id}
            section={section}
            expanded={expanded === section.id}
            onToggle={() => setExpanded(expanded === section.id ? '' : section.id)}
          />
        ))}
      </div>

      {/* Footer note */}
      <div className="mt-10 p-5 bg-ghost-gold/5 border border-ghost-gold/20">
        <p className="text-ghost-gold font-barlow font-bold text-xs uppercase tracking-wider mb-2">
          Note importante
        </p>
        <p className="text-ghost-gray text-sm leading-relaxed">
          Les administrateurs se réservent le droit de modifier le règlement à tout moment. Toute modification sera communiquée via le système de notifications en jeu.
        </p>
      </div>
    </div>
  );
}
