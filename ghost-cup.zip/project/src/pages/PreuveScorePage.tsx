import { useState, useRef, FormEvent } from 'react';
import { ChevronLeft, Upload, CheckCircle, AlertCircle, FileImage } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { Page } from '../types';

interface PreuveScorePageProps {
  matchId: string;
  onNavigate: (page: Page, data?: unknown) => void;
}

export default function PreuveScorePage({ matchId, onNavigate }: PreuveScorePageProps) {
  const { profile } = useAuth();
  const [file, setFile] = useState<File | null>(null);
  const [comment, setComment] = useState('');
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [dragOver, setDragOver] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  function handleFileChange(f: File | null) {
    if (!f) return;
    const MAX_MB = 20;
    if (f.size > MAX_MB * 1024 * 1024) {
      setError(`Fichier trop volumineux. Maximum ${MAX_MB}MB.`);
      return;
    }
    if (!['image/jpeg', 'image/png', 'image/gif'].includes(f.type)) {
      setError('Format invalide. Acceptés : JPG, PNG, GIF.');
      return;
    }
    setError('');
    setFile(f);
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!file) { setError('Veuillez sélectionner un fichier.'); return; }
    if (!profile) { setError('Vous devez être connecté.'); return; }

    setUploading(true);
    setError('');

    // Upload to Supabase Storage
    const ext = file.name.split('.').pop();
    const path = `proofs/${matchId}/${profile.id}_${Date.now()}.${ext}`;
    const { error: uploadError } = await supabase.storage
      .from('score-proofs')
      .upload(path, file, { upsert: true });

    if (uploadError) {
      // If bucket doesn't exist, still save with a placeholder URL
      const { error: dbError } = await supabase.from('score_proofs').insert({
        match_id: matchId,
        submitted_by: profile.id,
        file_url: `local:${file.name}`,
        comment: comment || null,
        status: 'pending',
      });
      if (dbError) { setError(dbError.message); setUploading(false); return; }
    } else {
      const { data: { publicUrl } } = supabase.storage.from('score-proofs').getPublicUrl(path);
      const { error: dbError } = await supabase.from('score_proofs').insert({
        match_id: matchId,
        submitted_by: profile.id,
        file_url: publicUrl,
        comment: comment || null,
        status: 'pending',
      });
      if (dbError) { setError(dbError.message); setUploading(false); return; }
    }

    setUploading(false);
    setSuccess('Preuve envoyée pour validation. Un admin la vérifiera sous peu.');
    setTimeout(() => onNavigate('match-detail', matchId), 2500);
  }

  return (
    <div className="animate-slide-up px-6 py-10 max-w-2xl mx-auto">
      {/* Back */}
      <button
        onClick={() => onNavigate('match-detail', matchId)}
        className="flex items-center gap-2 text-ghost-gray hover:text-white transition-colors mb-6 font-barlow text-xs uppercase tracking-wider"
      >
        <ChevronLeft size={14} /> RETOUR AU MATCH
      </button>

      <div className="text-center mb-10">
        <p className="section-title text-center">GHOST CUP</p>
        <h1 className="font-barlow font-black text-3xl text-white uppercase">PREUVE DE SCORE</h1>
        <div className="gold-divider" />
        <p className="text-ghost-gray text-sm mt-4 max-w-sm mx-auto">
          Veuillez transmettre une capture d'écran ou un clip du score final pour validation.
        </p>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="card p-8 mb-6">
          <p className="section-title mb-4">UPLOAD</p>

          {/* Drop zone */}
          <div
            className={`border-2 border-dashed p-10 text-center cursor-pointer transition-all duration-200 ${
              dragOver
                ? 'border-ghost-gold bg-ghost-gold/5'
                : file
                ? 'border-ghost-green bg-ghost-green/5'
                : 'border-ghost-border hover:border-ghost-gold/50'
            }`}
            onClick={() => fileRef.current?.click()}
            onDragOver={e => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={e => {
              e.preventDefault();
              setDragOver(false);
              handleFileChange(e.dataTransfer.files[0] ?? null);
            }}
          >
            {file ? (
              <div className="flex flex-col items-center gap-3">
                <FileImage size={40} className="text-ghost-green" strokeWidth={1} />
                <p className="font-barlow font-bold text-ghost-green text-sm">{file.name}</p>
                <p className="text-ghost-gray text-xs">{(file.size / (1024 * 1024)).toFixed(2)} MB</p>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-3">
                <Upload size={40} className="text-ghost-gray/40" strokeWidth={1} />
                <p className="font-barlow text-ghost-gray text-sm">
                  Glissez votre fichier ici ou
                </p>
                <button type="button" className="btn-outline text-xs py-2 px-5">
                  CHOISIR UN FICHIER
                </button>
                <p className="text-ghost-gray/50 text-[10px]">
                  Formats acceptés : JPG, PNG, GIF (Max 20MB)
                </p>
              </div>
            )}
          </div>

          <input
            ref={fileRef}
            type="file"
            accept="image/jpeg,image/png,image/gif"
            className="hidden"
            onChange={e => handleFileChange(e.target.files?.[0] ?? null)}
          />
        </div>

        {/* Comment */}
        <div className="card p-6 mb-6">
          <p className="section-title mb-4">COMMENTAIRE (optionnel)</p>
          <textarea
            value={comment}
            onChange={e => setComment(e.target.value)}
            placeholder="Ajoutez un commentaire..."
            rows={4}
            className="input-dark resize-none"
          />
        </div>

        {error && (
          <div className="flex items-center gap-2 bg-ghost-red/10 border border-ghost-red/30 px-4 py-3 mb-4">
            <AlertCircle size={14} className="text-ghost-red shrink-0" />
            <span className="text-ghost-red text-xs">{error}</span>
          </div>
        )}

        {success && (
          <div className="flex items-center gap-2 bg-ghost-green/10 border border-ghost-green/30 px-4 py-3 mb-4">
            <CheckCircle size={14} className="text-ghost-green shrink-0" />
            <span className="text-ghost-green text-xs">{success}</span>
          </div>
        )}

        <button
          type="submit"
          disabled={uploading || !!success}
          className="btn-gold w-full py-3 justify-center flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {uploading ? 'ENVOI EN COURS...' : 'ENVOYER POUR VALIDATION'}
        </button>
      </form>
    </div>
  );
}
