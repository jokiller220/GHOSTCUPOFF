import { useEffect, useState } from 'react';
import { Clock, ChevronRight, Upload } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Match, Page } from '../types';

interface MesMatchsPageProps {
  onNavigate: (page: Page, data?: unknown) => void;
}

const STATUS_LABELS: Record<string, { label: string; class: string }> = {
  scheduled: { label: 'À VENIR', class: 'text-ghost-gray border-ghost-border' },
  live: { label: 'EN COURS', class: 'text-ghost-red border-ghost-red/40 bg-ghost-red/10' },
  completed: { label: 'TERMINÉ', class: 'text-ghost-green border-ghost-green/40 bg-ghost-green/10' },
  forfeit: { label: 'FORFAIT', class: 'text-ghost-red border-ghost-red/40' },
  postponed: { label: 'REPORTÉ', class: 'text-ghost-gold border-ghost-gold/40' },
};

export default function MesMatchsPage({ onNavigate }: MesMatchsPageProps) {
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from('matches')
        .select('*, scores:match_scores(*)')
        .order('scheduled_at', { ascending: false });
      setMatches((data as Match[]) ?? []);
      setLoading(false);
    })();
  }, []);

  function formatDate(d?: string) {
    if (!d) return 'TBD';
    return new Date(d).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' }) +
      ' — ' + new Date(d).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  }

  return (
    <div className="animate-slide-up">
      <div className="mb-8">
        <p className="section-title">GHOST CUP</p>
        <h1 className="font-barlow font-black text-3xl text-white uppercase">MES MATCHS</h1>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-48 text-ghost-gray text-sm font-barlow uppercase tracking-wider">Chargement...</div>
      ) : matches.length === 0 ? (
        <div className="card p-12 text-center">
          <Clock size={32} className="mx-auto mb-3 text-ghost-gray/30" />
          <p className="font-barlow text-ghost-gray text-sm uppercase tracking-wider">Aucun match</p>
        </div>
      ) : (
        <div className="space-y-3">
          {matches.map(match => {
            const statusInfo = STATUS_LABELS[match.status] || STATUS_LABELS.scheduled;
            const score1 = match.scores?.filter(s => s.team1_score > s.team2_score).length ?? 0;
            const score2 = match.scores?.filter(s => s.team2_score > s.team1_score).length ?? 0;
            return (
              <div
                key={match.id}
                className="card hover:border-ghost-gold/30 transition-all duration-200 cursor-pointer group"
                onClick={() => onNavigate('match-detail', match.id)}
              >
                <div className="flex items-center gap-5 px-5 py-4 flex-wrap">
                  {/* Format */}
                  <span className="font-barlow font-bold text-ghost-gold text-xs border border-ghost-gold/30 px-2 py-0.5 shrink-0">
                    {match.format}
                  </span>

                  {/* Teams */}
                  <div className="flex-1 min-w-[200px]">
                    <div className="flex items-center gap-2">
                      <span className="font-barlow font-black text-white text-sm group-hover:text-ghost-gold transition-colors">
                        {match.team1_name ?? 'TBD'}
                      </span>
                      {match.status === 'completed' && (
                        <span className="font-barlow font-black text-ghost-gold text-sm">{score1} — {score2}</span>
                      )}
                      <span className="font-barlow font-bold text-ghost-gray text-xs">vs</span>
                      <span className="font-barlow font-black text-white text-sm group-hover:text-ghost-gold transition-colors">
                        {match.team2_name ?? 'TBD'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-ghost-gray text-[10px] font-barlow">{match.round_name}</span>
                      <span className="text-ghost-border">·</span>
                      <span className="text-ghost-gray text-[10px] font-barlow flex items-center gap-1">
                        <Clock size={10} /> {formatDate(match.scheduled_at)}
                      </span>
                    </div>
                  </div>

                  {/* Status */}
                  <span className={`status-badge border px-2 py-0.5 ${statusInfo.class}`}>
                    {statusInfo.label}
                  </span>

                  {/* Upload proof for completed */}
                  {match.status === 'completed' && (
                    <button
                      onClick={e => { e.stopPropagation(); onNavigate('preuve-score', match.id); }}
                      className="btn-outline text-[10px] py-1.5 px-3 flex items-center gap-1.5"
                    >
                      <Upload size={10} /> PREUVE
                    </button>
                  )}

                  <ChevronRight size={14} className="text-ghost-gray group-hover:text-ghost-gold transition-colors shrink-0" />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
