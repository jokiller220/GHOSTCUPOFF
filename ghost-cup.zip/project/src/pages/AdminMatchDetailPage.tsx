import { useEffect, useState } from 'react';
import { ChevronLeft, Check, Edit2, Flag, Calendar, XCircle, AlertCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Match, MatchScore, Page } from '../types';
import { useAuth } from '../context/AuthContext';

interface AdminMatchDetailPageProps {
  matchId: string;
  onNavigate: (page: Page, data?: unknown) => void;
}

type ActiveTab = 'score' | 'params' | 'history';

export default function AdminMatchDetailPage({ matchId, onNavigate }: AdminMatchDetailPageProps) {
  const { profile } = useAuth();
  const [match, setMatch] = useState<Match | null>(null);
  const [scores, setScores] = useState<MatchScore[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<ActiveTab>('score');
  const [editScores, setEditScores] = useState<Record<number, { t1: string; t2: string }>>({});
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    load();
  }, [matchId]);

  async function load() {
    setLoading(true);
    const { data } = await supabase
      .from('matches')
      .select('*')
      .eq('id', matchId)
      .maybeSingle();
    setMatch(data as Match);

    const { data: sc } = await supabase
      .from('match_scores')
      .select('*')
      .eq('match_id', matchId)
      .order('manche_number');
    setScores((sc as MatchScore[]) ?? []);

    // Initialize edit state
    const init: Record<number, { t1: string; t2: string }> = {};
    for (let i = 1; i <= 5; i++) {
      const s = (sc as MatchScore[])?.find(x => x.manche_number === i);
      init[i] = { t1: s?.team1_score?.toString() ?? '', t2: s?.team2_score?.toString() ?? '' };
    }
    setEditScores(init);
    setLoading(false);
  }

  async function saveScores() {
    setSaving(true);
    setError('');
    try {
      for (let i = 1; i <= 5; i++) {
        const { t1, t2 } = editScores[i] ?? { t1: '', t2: '' };
        if (t1 === '' && t2 === '') continue;
        const t1n = parseInt(t1) || 0;
        const t2n = parseInt(t2) || 0;
        const existing = scores.find(s => s.manche_number === i);
        if (existing) {
          await supabase.from('match_scores').update({ team1_score: t1n, team2_score: t2n }).eq('id', existing.id);
        } else {
          await supabase.from('match_scores').insert({ match_id: matchId, manche_number: i, team1_score: t1n, team2_score: t2n });
        }
      }
      await logActivity('score_validated', { match: `${match?.team1_name} vs ${match?.team2_name}`, desc: `Score modifié par admin` });
      await load();
      setSuccess('Scores mis à jour.');
      setTimeout(() => setSuccess(''), 3000);
    } catch {
      setError('Erreur lors de la sauvegarde.');
    }
    setSaving(false);
  }

  async function logActivity(action: string, details: object) {
    await supabase.from('activity_logs').insert({ admin_id: profile?.id, action, details });
  }

  async function updateMatchStatus(status: string) {
    setSaving(true);
    await supabase.from('matches').update({ status }).eq('id', matchId);
    await logActivity('status_updated', { match: `${match?.team1_name} vs ${match?.team2_name}`, status });
    await load();
    setSuccess(`Statut mis à jour : ${status}`);
    setTimeout(() => setSuccess(''), 3000);
    setSaving(false);
  }

  async function validateScore() {
    if (!match) return;
    // Determine winner
    const t1W = scores.filter(s => s.team1_score > s.team2_score).length;
    const t2W = scores.filter(s => s.team2_score > s.team1_score).length;
    const winnerId = t1W > t2W ? match.team1_id : t2W > t1W ? match.team2_id : null;
    setSaving(true);
    await supabase.from('matches').update({ status: 'completed', winner_id: winnerId }).eq('id', matchId);
    await logActivity('score_validated', { match: `${match.team1_name} vs ${match.team2_name}`, desc: `Score validé : ${t1W}-${t2W}` });
    await load();
    setSuccess('Score validé. Match terminé.');
    setTimeout(() => setSuccess(''), 3000);
    setSaving(false);
  }

  if (loading) return (
    <div className="flex items-center justify-center h-64 text-ghost-gray text-sm font-barlow uppercase">Chargement...</div>
  );

  if (!match) return (
    <div className="text-center py-12 text-ghost-gray">
      <p className="font-barlow uppercase tracking-wider">Match introuvable</p>
    </div>
  );

  const t1Wins = scores.filter(s => s.team1_score > s.team2_score).length;
  const t2Wins = scores.filter(s => s.team2_score > s.team1_score).length;

  return (
    <div className="animate-slide-up">
      {/* Back */}
      <button
        onClick={() => onNavigate('admin-matchs')}
        className="flex items-center gap-2 text-ghost-gray hover:text-white transition-colors mb-6 font-barlow text-xs uppercase tracking-wider"
      >
        <ChevronLeft size={14} /> RETOUR
      </button>

      <div className="mb-6">
        <p className="section-title">ADMIN — GESTION DU MATCH</p>
        <h1 className="font-barlow font-black text-2xl text-white uppercase">
          {match.round_name} — {match.format}
        </h1>
      </div>

      {/* Match header */}
      <div className="card p-6 mb-6">
        <div className="flex items-center justify-center gap-10 flex-wrap">
          <div className="text-center">
            <div className="w-16 h-16 mx-auto bg-ghost-gold/10 border border-ghost-gold/30 flex items-center justify-center mb-2">
              <span className="font-barlow font-black text-ghost-gold text-2xl">{match.team1_name?.[0] ?? '?'}</span>
            </div>
            <p className="font-barlow font-black text-white text-lg uppercase">{match.team1_name ?? 'TBD'}</p>
          </div>
          <div className="text-center">
            <p className="font-barlaw font-black text-ghost-gold text-4xl font-barlow font-black">{t1Wins} — {t2Wins}</p>
            <p className="text-ghost-gray text-xs font-barlow uppercase tracking-wider mt-1">Score actuel</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 mx-auto bg-ghost-gold/10 border border-ghost-gold/30 flex items-center justify-center mb-2">
              <span className="font-barlow font-black text-ghost-gold text-2xl">{match.team2_name?.[0] ?? '?'}</span>
            </div>
            <p className="font-barlow font-black text-white text-lg uppercase">{match.team2_name ?? 'TBD'}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main panel */}
        <div className="lg:col-span-2">
          {/* Tabs */}
          <div className="flex border-b border-ghost-border mb-6">
            {([
              { key: 'score', label: 'SCORE' },
              { key: 'params', label: 'PARAMÈTRES' },
              { key: 'history', label: 'HISTORIQUE' },
            ] as { key: ActiveTab; label: string }[]).map(({ key, label }) => (
              <button
                key={key}
                onClick={() => setActiveTab(key)}
                className={`px-6 py-3 font-barlow font-black text-xs uppercase tracking-widest border-b-2 transition-all duration-200 ${
                  activeTab === key ? 'text-ghost-gold border-ghost-gold' : 'text-ghost-gray border-transparent hover:text-white'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {activeTab === 'score' && (
            <div className="card p-6">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-ghost-border">
                    <th className="text-ghost-gray text-[10px] font-barlow uppercase tracking-wider text-left pb-2 w-24"></th>
                    <th className="text-white text-xs font-barlow font-black uppercase pb-2 text-center">
                      {match.team1_name?.substring(0, 12) ?? 'Team 1'}
                    </th>
                    <th className="text-white text-xs font-barlow font-black uppercase pb-2 text-center">
                      {match.team2_name?.substring(0, 12) ?? 'Team 2'}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {[1, 2, 3, 4, 5].map(i => {
                    const ev = editScores[i] ?? { t1: '', t2: '' };
                    return (
                      <tr key={i} className="border-b border-ghost-border/30">
                        <td className="py-3 text-ghost-gray text-xs font-barlow">Manche {i}</td>
                        <td className="py-3 px-2">
                          <input
                            type="number"
                            value={ev.t1}
                            onChange={e => setEditScores(prev => ({ ...prev, [i]: { ...prev[i], t1: e.target.value } }))}
                            placeholder="—"
                            className="input-dark text-center text-sm font-barlow font-black py-2 px-3 w-full"
                          />
                        </td>
                        <td className="py-3 px-2">
                          <input
                            type="number"
                            value={ev.t2}
                            onChange={e => setEditScores(prev => ({ ...prev, [i]: { ...prev[i], t2: e.target.value } }))}
                            placeholder="—"
                            className="input-dark text-center text-sm font-barlow font-black py-2 px-3 w-full"
                          />
                        </td>
                      </tr>
                    );
                  })}
                  <tr className="border-t border-ghost-border bg-ghost-black/20">
                    <td className="py-3 text-ghost-gold text-xs font-barlow font-black uppercase">SCORE FINAL</td>
                    <td className={`py-3 text-xl font-barlow font-black text-center ${t1Wins >= t2Wins && scores.length > 0 ? 'text-ghost-gold' : 'text-white'}`}>
                      {t1Wins}
                    </td>
                    <td className={`py-3 text-xl font-barlow font-black text-center ${t2Wins > t1Wins ? 'text-ghost-gold' : 'text-white'}`}>
                      {t2Wins}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}

          {activeTab === 'params' && (
            <div className="card p-6 space-y-4">
              {[
                { label: 'Mode de jeu', value: match.mode ?? '', field: 'mode' },
                { label: 'Carte', value: match.map ?? '', field: 'map' },
              ].map(({ label, value, field }) => (
                <div key={field}>
                  <label className="block text-ghost-gray text-xs font-barlow uppercase tracking-widest mb-2">{label}</label>
                  <input
                    defaultValue={value}
                    placeholder={`Ex: ${label}`}
                    className="input-dark"
                    onBlur={async e => {
                      await supabase.from('matches').update({ [field]: e.target.value }).eq('id', matchId);
                    }}
                  />
                </div>
              ))}
              <div>
                <label className="block text-ghost-gray text-xs font-barlow uppercase tracking-widest mb-2">Notes admin</label>
                <textarea
                  defaultValue={match.admin_notes ?? ''}
                  rows={3}
                  className="input-dark resize-none"
                  onBlur={async e => {
                    await supabase.from('matches').update({ admin_notes: e.target.value }).eq('id', matchId);
                  }}
                />
              </div>
            </div>
          )}

          {activeTab === 'history' && (
            <div className="card p-6">
              <p className="text-ghost-gray text-sm font-barlow uppercase tracking-wider text-center py-8">
                Historique des modifications à venir
              </p>
            </div>
          )}

          {(error || success) && (
            <div className={`mt-4 flex items-center gap-2 px-4 py-3 ${error ? 'bg-ghost-red/10 border-ghost-red/30 text-ghost-red' : 'bg-ghost-green/10 border-ghost-green/30 text-ghost-green'} border`}>
              {error ? <AlertCircle size={14} /> : <Check size={14} />}
              <span className="text-xs">{error || success}</span>
            </div>
          )}
        </div>

        {/* Actions panel */}
        <div>
          <p className="section-title mb-4">ACTIONS</p>
          <div className="flex flex-col gap-3">
            <button
              onClick={validateScore}
              disabled={saving || scores.length === 0}
              className="btn-gold text-xs py-3 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Check size={14} /> VALIDER LE SCORE
            </button>
            <button
              onClick={saveScores}
              disabled={saving}
              className="btn-dark text-xs py-3 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Edit2 size={14} /> MODIFIER LE SCORE
            </button>
            <button
              onClick={() => updateMatchStatus('forfeit')}
              disabled={saving}
              className="btn-red text-xs py-3 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Flag size={14} /> DÉCLARER FORFAIT
            </button>
            <button
              onClick={() => updateMatchStatus('postponed')}
              disabled={saving}
              className="btn-outline text-xs py-3 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Calendar size={14} /> REPROGRAMMER
            </button>
            <button
              onClick={() => {
                if (confirm('Confirmer la disqualification ?')) updateMatchStatus('forfeit');
              }}
              disabled={saving}
              className="text-ghost-red border border-ghost-red/30 font-barlow font-bold uppercase tracking-widest text-xs py-3 flex items-center justify-center gap-2 hover:bg-ghost-red/10 transition-all duration-200 disabled:opacity-50"
            >
              <XCircle size={14} /> DISQUALIFIER
            </button>
          </div>

          {/* Match status */}
          <div className="mt-6 card p-4">
            <p className="section-title mb-3">STATUT</p>
            <div className="flex flex-col gap-2">
              {['scheduled', 'live', 'completed', 'postponed'].map(s => (
                <button
                  key={s}
                  onClick={() => updateMatchStatus(s)}
                  className={`text-xs py-2 px-3 font-barlow font-bold uppercase tracking-wider text-left transition-all duration-200 border ${
                    match.status === s
                      ? s === 'live' ? 'border-ghost-red bg-ghost-red/10 text-ghost-red'
                      : s === 'completed' ? 'border-ghost-green bg-ghost-green/10 text-ghost-green'
                      : 'border-ghost-gold bg-ghost-gold/10 text-ghost-gold'
                      : 'border-ghost-border text-ghost-gray hover:border-ghost-gold/30 hover:text-white'
                  }`}
                >
                  {s === 'scheduled' ? 'À venir' : s === 'live' ? 'En cours' : s === 'completed' ? 'Terminé' : 'Reporté'}
                  {match.status === s && <span className="ml-2 text-[8px]">✓</span>}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
