import { useEffect, useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Match, Format, Page } from '../types';
import BracketTree from '../components/BracketTree';

interface BracketPageProps {
  onNavigate: (page: Page, data?: unknown) => void;
}

export default function BracketPage({ onNavigate }: BracketPageProps) {
  const [format, setFormat] = useState<Format>('5v5');
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);

  async function fetchMatches() {
    setLoading(true);
    const { data } = await supabase
      .from('matches')
      .select('*, scores:match_scores(*)')
      .eq('format', format)
      .order('round_order')
      .order('match_order');
    setMatches((data as Match[]) ?? []);
    setLoading(false);
  }

  useEffect(() => { fetchMatches(); }, [format]);

  // Realtime subscription
  useEffect(() => {
    const sub = supabase
      .channel('bracket-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'matches' }, fetchMatches)
      .subscribe();
    return () => { supabase.removeChannel(sub); };
  }, [format]);

  const liveMatches = matches.filter(m => m.status === 'live');

  return (
    <div className="px-6 py-10 animate-slide-up">
      {/* Header */}
      <div className="flex items-center justify-between mb-8 flex-wrap gap-4">
        <div>
          <p className="section-title">GHOST CUP 2025</p>
          <h1 className="font-barlow font-black text-3xl text-white uppercase">BRACKET PUBLIC</h1>
          <p className="text-ghost-gray text-xs uppercase tracking-wider mt-1">Mis à jour en temps réel</p>
        </div>
        <button
          onClick={fetchMatches}
          className="btn-outline text-xs py-2 px-4 flex items-center gap-2"
        >
          <RefreshCw size={12} />
          ACTUALISER
        </button>
      </div>

      {/* Live indicator */}
      {liveMatches.length > 0 && (
        <div className="mb-6 flex items-center gap-3 bg-ghost-red/10 border border-ghost-red/30 px-4 py-3">
          <span className="w-2 h-2 rounded-full bg-ghost-red live-indicator" />
          <span className="font-barlow font-bold text-ghost-red text-xs uppercase tracking-wider">
            {liveMatches.length} match{liveMatches.length > 1 ? 's' : ''} en cours
          </span>
        </div>
      )}

      {/* Format tabs */}
      <div className="flex border-b border-ghost-border mb-8">
        {(['5v5', '1v1'] as Format[]).map(f => (
          <button
            key={f}
            onClick={() => setFormat(f)}
            className={`px-8 py-3 font-barlow font-black text-sm uppercase tracking-widest border-b-2 transition-all duration-200 ${
              format === f
                ? 'text-ghost-gold border-ghost-gold'
                : 'text-ghost-gray border-transparent hover:text-white'
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Bracket */}
      {loading ? (
        <div className="flex items-center justify-center h-48 gap-3 text-ghost-gray">
          <RefreshCw size={16} className="animate-spin" />
          <span className="font-barlow uppercase tracking-wider text-sm">Chargement...</span>
        </div>
      ) : (
        <div className="card p-6 border-ghost-border overflow-hidden">
          <BracketTree
            matches={matches}
            onMatchClick={(m) => onNavigate('match-detail', m.id)}
          />
        </div>
      )}

      {/* Legend */}
      <div className="mt-6 flex flex-wrap gap-6">
        {[
          { color: 'bg-ghost-green', label: 'Terminé' },
          { color: 'bg-ghost-red', label: 'En cours' },
          { color: 'bg-ghost-border', label: 'À venir' },
        ].map(({ color, label }) => (
          <div key={label} className="flex items-center gap-2">
            <span className={`w-2.5 h-2.5 rounded-full ${color}`} />
            <span className="text-ghost-gray text-xs font-barlow uppercase tracking-wider">{label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
