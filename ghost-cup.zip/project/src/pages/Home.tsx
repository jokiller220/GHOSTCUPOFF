import { Trophy, Target, Users, Zap, ChevronRight, Twitter, Youtube } from 'lucide-react';
import { Page } from '../types';
import Countdown from '../components/Countdown';

interface HomeProps {
  onNavigate: (page: Page) => void;
}

const FINAL_DATE = '2025-06-15T18:00:00';

export default function Home({ onNavigate }: HomeProps) {
  return (
    <div className="flex flex-col">
      {/* Hero section */}
      <section
        className="relative min-h-[90vh] flex items-center justify-center overflow-hidden"
        style={{
          background: 'linear-gradient(135deg, #0a0a0a 0%, #111111 40%, #0f0c08 100%)',
        }}
      >
        {/* Background texture overlay */}
        <div
          className="absolute inset-0 opacity-5"
          style={{
            backgroundImage: `url("https://images.pexels.com/photos/3944091/pexels-photo-3944091.jpeg?auto=compress&cs=tinysrgb&w=1920")`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            filter: 'grayscale(100%) contrast(150%)',
          }}
        />
        {/* Gold vignette */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-ghost-black" />
        <div
          className="absolute inset-0 opacity-10"
          style={{
            background: 'radial-gradient(ellipse 80% 60% at 50% 40%, rgba(201,162,39,0.3) 0%, transparent 70%)',
          }}
        />

        {/* Soldier image */}
        <div className="absolute right-0 bottom-0 h-full w-1/2 hidden lg:block overflow-hidden">
          <img
            src="https://images.pexels.com/photos/6895826/pexels-photo-6895826.jpeg?auto=compress&cs=tinysrgb&w=800"
            alt="Ghost Cup soldier"
            className="h-full w-full object-cover object-top opacity-25"
            style={{ filter: 'grayscale(80%) contrast(130%)' }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-ghost-black via-ghost-black/80 to-transparent" />
        </div>

        {/* Hero content */}
        <div className="relative z-10 max-w-7xl mx-auto px-6 py-20 w-full">
          <div className="max-w-2xl">
            {/* Tag */}
            <div className="inline-flex items-center gap-2 bg-ghost-gold/10 border border-ghost-gold/30 px-4 py-1.5 mb-8">
              <span className="w-1.5 h-1.5 rounded-full bg-ghost-gold live-indicator" />
              <span className="font-barlow font-bold text-ghost-gold text-xs uppercase tracking-widest">
                Tournoi Call of Duty — Édition 2025
              </span>
            </div>

            <h1 className="font-barlow font-black uppercase leading-none mb-4">
              <span className="block text-5xl md:text-7xl lg:text-8xl text-white tracking-tight">GHOST</span>
              <span className="block text-5xl md:text-7xl lg:text-8xl text-ghost-gold tracking-tight">CUP</span>
            </h1>
            <p className="font-barlow font-bold text-ghost-gray-light uppercase tracking-[0.3em] text-sm md:text-base mb-2">
              Le Tournoi Call of Duty
            </p>
            <p className="font-barlow font-black text-white uppercase tracking-widest text-lg md:text-xl mb-10">
              5VS5 & 1V1
            </p>

            {/* Finale date */}
            <div className="mb-8">
              <p className="font-barlow text-ghost-gray text-xs uppercase tracking-widest mb-1">Finale</p>
              <p className="font-barlow font-black text-white text-2xl md:text-3xl uppercase tracking-wider">
                15 JUIN 2025
              </p>
            </div>

            {/* Countdown */}
            <div className="mb-10">
              <p className="font-barlow text-ghost-gray text-xs uppercase tracking-widest mb-4">Compte à rebours</p>
              <Countdown targetDate={FINAL_DATE} />
            </div>

            {/* CTA buttons */}
            <div className="flex flex-wrap gap-4">
              <button
                onClick={() => onNavigate('auth')}
                className="btn-gold text-sm flex items-center gap-2 py-3 px-8"
              >
                S'INSCRIRE AU TOURNOI
                <ChevronRight size={16} />
              </button>
              <button
                onClick={() => onNavigate('bracket')}
                className="btn-outline text-sm py-3 px-8"
              >
                VOIR LE BRACKET
              </button>
            </div>

            {/* Hashtag */}
            <p className="font-barlow font-bold text-ghost-gold/50 text-sm uppercase tracking-widest mt-8">
              #GHOSTCUP
            </p>
          </div>
        </div>

        {/* Format cards */}
        <div className="absolute bottom-8 left-6 right-6 z-10 max-w-7xl mx-auto">
          <div className="flex gap-4 flex-wrap">
            <div
              className="flex-1 min-w-[160px] bg-ghost-dark/80 border border-ghost-gold/30 px-6 py-4 cursor-pointer hover:border-ghost-gold transition-all duration-300 group backdrop-blur"
              onClick={() => onNavigate('auth')}
            >
              <div className="flex items-center gap-3 mb-2">
                <Users size={20} className="text-ghost-gold" />
                <span className="font-barlow font-black text-2xl text-white group-hover:text-ghost-gold transition-colors">5 VS 5</span>
              </div>
              <p className="font-barlow text-ghost-gray text-xs uppercase tracking-wider">Équipes de 5</p>
            </div>
            <div
              className="flex-1 min-w-[160px] bg-ghost-dark/80 border border-ghost-gold/30 px-6 py-4 cursor-pointer hover:border-ghost-gold transition-all duration-300 group backdrop-blur"
              onClick={() => onNavigate('auth')}
            >
              <div className="flex items-center gap-3 mb-2">
                <Target size={20} className="text-ghost-gold" />
                <span className="font-barlow font-black text-2xl text-white group-hover:text-ghost-gold transition-colors">1 VS 1</span>
              </div>
              <p className="font-barlow text-ghost-gray text-xs uppercase tracking-wider">Duel Individuel</p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats band */}
      <section className="bg-ghost-gold py-4">
        <div className="max-w-7xl mx-auto px-6 flex flex-wrap gap-8 justify-center items-center">
          {[
            { label: 'Joueurs inscrits', value: '128' },
            { label: 'Équipes 5v5', value: '32' },
            { label: 'Matchs joués', value: '24' },
            { label: 'Prix en jeu', value: 'Trophées + Avatars' },
          ].map(({ label, value }) => (
            <div key={label} className="text-center">
              <p className="font-barlow font-black text-black text-xl uppercase leading-none">{value}</p>
              <p className="font-barlow text-black/70 text-[10px] uppercase tracking-widest mt-0.5">{label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* About section */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <div>
            <p className="section-title">À PROPOS</p>
            <h2 className="font-barlow font-black text-4xl md:text-5xl text-white uppercase leading-tight mb-6">
              UN SEUL OBJECTIF :<br />
              <span className="text-ghost-gold">LA VICTOIRE</span>
            </h2>
            <p className="text-ghost-gray text-sm leading-relaxed mb-6">
              La Ghost Cup est le tournoi Call of Duty incontournable de la saison. Deux formats, deux chances de briller — rejoignez une équipe de 5 pour les batailles stratégiques, ou dominez en duel 1v1. Chaque match compte. Chaque élimination est définitive.
            </p>
            <div className="flex gap-4 flex-wrap">
              <button onClick={() => onNavigate('reglement')} className="btn-outline text-xs py-2">
                Voir le règlement
              </button>
              <button onClick={() => onNavigate('recompenses')} className="btn-gold text-xs py-2">
                Les récompenses
              </button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[
              { icon: <Zap size={24} className="text-ghost-gold" />, title: 'BO5', desc: 'Best of 5 manches pour chaque match' },
              { icon: <Target size={24} className="text-ghost-gold" />, title: 'Hardpoint', desc: 'Mode principal en 5v5 — contrôle de zone' },
              { icon: <Trophy size={24} className="text-ghost-gold" />, title: 'Trophée', desc: 'Trophée exclusif + avatar Ghost Cup' },
              { icon: <Users size={24} className="text-ghost-gold" />, title: 'Double Format', desc: '5v5 équipe et 1v1 en simultané' },
            ].map(({ icon, title, desc }) => (
              <div key={title} className="card p-5 hover:border-ghost-gold/30 transition-all duration-300">
                <div className="mb-3">{icon}</div>
                <p className="font-barlow font-black text-white uppercase text-sm mb-1">{title}</p>
                <p className="text-ghost-gray text-xs leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA section */}
      <section className="bg-ghost-dark border-y border-ghost-border py-16 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <p className="section-title text-center">REJOINS L'ARÈNE</p>
          <h2 className="font-barlow font-black text-4xl md:text-5xl text-white uppercase mb-6">
            Prêt à dominer ?
          </h2>
          <p className="text-ghost-gray text-sm max-w-md mx-auto mb-8">
            Inscris-toi maintenant avant la clôture des inscriptions. Les brackets sont générés automatiquement au démarrage du tournoi.
          </p>
          <div className="flex justify-center gap-4 flex-wrap">
            <button onClick={() => onNavigate('auth')} className="btn-gold text-sm py-3 px-10 flex items-center gap-2">
              S'INSCRIRE <ChevronRight size={16} />
            </button>
            <button onClick={() => onNavigate('planning')} className="btn-outline text-sm py-3 px-8">
              VOIR LE PLANNING
            </button>
          </div>

          {/* Social */}
          <div className="flex justify-center gap-6 mt-10">
            {[
              { icon: <Twitter size={18} />, label: 'Twitter' },
              { icon: <Youtube size={18} />, label: 'YouTube' },
            ].map(({ icon, label }) => (
              <button key={label} className="flex items-center gap-2 text-ghost-gray hover:text-ghost-gold transition-colors text-xs font-barlow uppercase tracking-wider">
                {icon} {label}
              </button>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
