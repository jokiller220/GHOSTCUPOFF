import { Trophy, Star, Crown, Award } from 'lucide-react';

const rewards = [
  {
    format: '5 VS 5',
    title: 'CHAMPION 5 VS 5',
    subtitle: 'Équipe victorieuse',
    icon: <Trophy size={64} className="text-ghost-gold" strokeWidth={1} />,
    prizes: [
      { label: 'Trophée exclusif', desc: 'Trophée Ghost Cup édition 2025 — objet collector unique' },
      { label: 'Avatar spécial', desc: 'Avatar Ghost Cup Champion exclusif, non disponible en boutique' },
      { label: 'Gloire éternelle', desc: 'Votre nom gravé dans le Hall of Fame Ghost Cup' },
    ],
    gradient: 'from-ghost-gold/20 to-transparent',
  },
  {
    format: '1 VS 1',
    title: 'CHAMPION 1 VS 1',
    subtitle: 'Duel victorieux',
    icon: <Crown size={64} className="text-ghost-gold" strokeWidth={1} />,
    prizes: [
      { label: 'Trophée exclusif', desc: 'Trophée Ghost Cup Solo édition 2025' },
      { label: 'Avatar spécial', desc: 'Avatar Ghost Cup Solo exclusif, animé' },
      { label: 'Gloire éternelle', desc: 'Titre "Roi du 1v1" affiché sur votre profil' },
    ],
    gradient: 'from-ghost-gold/20 to-transparent',
  },
];

const otherPrizes = [
  { place: '2e Place 5v5', icon: <Award size={32} className="text-gray-400" strokeWidth={1} />, prizes: ['Médaille Argent Ghost Cup', 'Badge Finaliste'] },
  { place: '3e Place 5v5', icon: <Award size={32} className="text-amber-700" strokeWidth={1} />, prizes: ['Médaille Bronze Ghost Cup', 'Badge Demi-Finaliste'] },
  { place: '2e Place 1v1', icon: <Star size={32} className="text-gray-400" strokeWidth={1} />, prizes: ['Médaille Argent Solo', 'Badge Finaliste Solo'] },
];

export default function Recompenses() {
  return (
    <div className="px-6 py-12 animate-slide-up">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-14">
          <p className="section-title text-center">GHOST CUP 2025</p>
          <h1 className="font-barlow font-black text-4xl md:text-5xl text-white uppercase mb-4">
            RÉCOMPENSES
          </h1>
          <div className="gold-divider" />
        </div>

        {/* Main rewards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          {rewards.map(({ format, title, subtitle, icon, prizes, gradient }) => (
            <div
              key={format}
              className={`card relative overflow-hidden hover:border-ghost-gold/40 transition-all duration-300 group`}
            >
              {/* Gradient bg */}
              <div className={`absolute inset-0 bg-gradient-to-b ${gradient} opacity-60 pointer-events-none`} />
              <div className="absolute inset-0 bg-gradient-to-t from-ghost-card to-transparent pointer-events-none" />

              <div className="relative p-8">
                {/* Format badge */}
                <div className="inline-flex items-center gap-2 bg-ghost-gold/10 border border-ghost-gold/30 px-3 py-1 mb-6">
                  <span className="font-barlow font-black text-ghost-gold text-xs uppercase tracking-widest">{format}</span>
                </div>

                {/* Trophy icon */}
                <div className="flex justify-center mb-6 group-hover:scale-105 transition-transform duration-300">
                  {icon}
                </div>

                {/* Title */}
                <h2 className="font-barlow font-black text-2xl text-white uppercase text-center mb-1">{title}</h2>
                <p className="font-barlow text-ghost-gray text-xs uppercase tracking-widest text-center mb-8">{subtitle}</p>

                {/* Prizes */}
                <div className="space-y-3">
                  {prizes.map(({ label, desc }) => (
                    <div key={label} className="flex items-start gap-3 p-3 bg-ghost-black/30 border border-ghost-border/30">
                      <span className="w-1.5 h-1.5 rounded-full bg-ghost-gold mt-1.5 shrink-0" />
                      <div>
                        <p className="font-barlow font-bold text-ghost-gold text-xs uppercase tracking-wider">{label}</p>
                        <p className="text-ghost-gray text-xs mt-0.5">{desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Tagline */}
        <div className="text-center mb-12">
          <div className="gold-divider" />
          <h3 className="font-barlow font-black text-2xl md:text-3xl text-white uppercase tracking-widest mt-6">
            UN SEUL OBJECTIF : <span className="text-ghost-gold">LA VICTOIRE !</span>
          </h3>
        </div>

        {/* Other prizes */}
        <div>
          <p className="section-title mb-6">AUTRES RÉCOMPENSES</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {otherPrizes.map(({ place, icon, prizes }) => (
              <div key={place} className="card p-6 hover:border-ghost-gold/20 transition-all duration-200">
                <div className="flex justify-center mb-4">{icon}</div>
                <p className="font-barlow font-black text-white uppercase text-center text-sm mb-4">{place}</p>
                <ul className="space-y-2">
                  {prizes.map(p => (
                    <li key={p} className="flex items-center gap-2 text-ghost-gray text-xs">
                      <span className="w-1 h-1 rounded-full bg-ghost-gray/50 shrink-0" />
                      {p}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Special combo */}
        <div className="mt-8 p-6 bg-ghost-gold/5 border border-ghost-gold/20 flex gap-4 items-start">
          <Crown size={32} className="text-ghost-gold shrink-0" strokeWidth={1} />
          <div>
            <p className="font-barlow font-black text-ghost-gold text-sm uppercase tracking-wider mb-2">
              ROI DE LA GHOST CUP
            </p>
            <p className="text-ghost-gray text-sm leading-relaxed">
              Le joueur qui performe dans <strong className="text-white">les deux formats simultanément</strong> (5v5 et 1v1) remporte le titre exclusif de "Roi de la Ghost Cup" avec un trophée combiné et un avatar ultra-rare.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
