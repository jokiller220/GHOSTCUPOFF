import { useEffect, useState } from 'react';
import { Users, Search, Crown, RefreshCw } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Profile, Team } from '../types';

export default function AdminJoueursPage() {
  const [players, setPlayers] = useState<Profile[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [tab, setTab] = useState<'players' | 'teams'>('players');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => { load(); }, [tab]);

  async function load() {
    setLoading(true);
    if (tab === 'players') {
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .eq('role', 'player')
        .order('created_at', { ascending: false });
      setPlayers((data as Profile[]) ?? []);
    } else {
      const { data } = await supabase
        .from('teams')
        .select('*, captain:profiles(cod_username)')
        .order('created_at', { ascending: false });
      setTeams((data as Team[]) ?? []);
    }
    setLoading(false);
  }

  const filteredPlayers = players.filter(p =>
    p.cod_username.toLowerCase().includes(search.toLowerCase()) ||
    p.real_name.toLowerCase().includes(search.toLowerCase())
  );

  const filteredTeams = teams.filter(t =>
    t.name.toLowerCase().includes(search.toLowerCase())
  );

  async function promoteAdmin(id: string) {
    if (!confirm('Promouvoir ce joueur en admin ?')) return;
    await supabase.from('profiles').update({ role: 'admin' }).eq('id', id);
    load();
  }

  const STATUS_COLORS: Record<string, string> = {
    forming: 'text-ghost-gray border-ghost-border',
    registered: 'text-ghost-gold border-ghost-gold/40',
    active: 'text-ghost-green border-ghost-green/40',
    eliminated: 'text-ghost-red border-ghost-red/40',
    champion: 'text-ghost-gold border-ghost-gold',
  };

  return (
    <div className="animate-slide-up">
      <div className="mb-8">
        <p className="section-title">ADMIN</p>
        <h1 className="font-barlow font-black text-3xl text-white uppercase">JOUEURS & ÉQUIPES</h1>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-ghost-border mb-6">
        {[
          { key: 'players', label: `JOUEURS (${players.length})` },
          { key: 'teams', label: `ÉQUIPES (${teams.length})` },
        ].map(({ key, label }) => (
          <button
            key={key}
            onClick={() => setTab(key as typeof tab)}
            className={`px-6 py-3 font-barlow font-black text-xs uppercase tracking-widest border-b-2 transition-all ${
              tab === key ? 'text-ghost-gold border-ghost-gold' : 'text-ghost-gray border-transparent hover:text-white'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="relative mb-6 max-w-sm">
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-ghost-gray" />
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Rechercher..."
          className="input-dark pl-9"
        />
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-48 gap-3 text-ghost-gray">
          <RefreshCw size={16} className="animate-spin" />
        </div>
      ) : tab === 'players' ? (
        <div className="space-y-2">
          {filteredPlayers.map(p => (
            <div key={p.id} className="card px-5 py-4 flex items-center gap-4 flex-wrap">
              <div className="w-8 h-8 bg-ghost-gold/10 border border-ghost-gold/20 flex items-center justify-center shrink-0">
                <span className="font-barlow font-black text-ghost-gold text-xs">{p.cod_username[0]}</span>
              </div>
              <div className="flex-1">
                <p className="font-barlow font-bold text-white text-sm">{p.cod_username}</p>
                <p className="text-ghost-gray text-xs">{p.real_name}</p>
              </div>
              <span className={`text-[9px] font-barlow font-bold uppercase border px-2 py-0.5 ${p.role === 'admin' ? 'text-ghost-red border-ghost-red/40' : 'text-ghost-gray border-ghost-border'}`}>
                {p.role}
              </span>
              <span className="text-ghost-gray text-[10px]">
                {new Date(p.created_at).toLocaleDateString('fr-FR')}
              </span>
              {p.role === 'player' && (
                <button onClick={() => promoteAdmin(p.id)} className="btn-outline text-[9px] py-1 px-2">
                  PROMOUVOIR
                </button>
              )}
            </div>
          ))}
          {filteredPlayers.length === 0 && (
            <div className="card p-10 text-center">
              <Users size={28} className="mx-auto mb-3 text-ghost-gray/30" />
              <p className="font-barlow text-ghost-gray text-sm uppercase tracking-wider">Aucun joueur trouvé</p>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-2">
          {filteredTeams.map(t => (
            <div key={t.id} className="card px-5 py-4 flex items-center gap-4 flex-wrap">
              <div className="w-10 h-10 bg-ghost-gold/10 border border-ghost-gold/20 flex items-center justify-center shrink-0">
                <span className="font-barlow font-black text-ghost-gold text-lg">{t.name[0]}</span>
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <p className="font-barlow font-bold text-white text-sm">{t.name}</p>
                  <Crown size={10} className="text-ghost-gold" />
                  <span className="text-ghost-gray text-xs">{(t.captain as Profile | undefined)?.cod_username ?? '—'}</span>
                </div>
                <p className="text-ghost-gray text-xs">{t.format.toUpperCase()} · Code: {t.invite_code}</p>
              </div>
              <span className={`text-[9px] font-barlow font-bold uppercase border px-2 py-0.5 ${STATUS_COLORS[t.status] ?? 'text-ghost-gray border-ghost-border'}`}>
                {t.status}
              </span>
            </div>
          ))}
          {filteredTeams.length === 0 && (
            <div className="card p-10 text-center">
              <Users size={28} className="mx-auto mb-3 text-ghost-gray/30" />
              <p className="font-barlow text-ghost-gray text-sm uppercase tracking-wider">Aucune équipe trouvée</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
