import { ReactNode } from 'react';
import {
  LayoutDashboard,
  Swords,
  Users,
  GitBranch,
  Megaphone,
  Trophy,
  Settings,
  LogOut,
  Shield,
} from 'lucide-react';
import { Page } from '../types';
import { useAuth } from '../context/AuthContext';
import Logo from './Logo';

interface AdminLayoutProps {
  children: ReactNode;
  currentPage: Page;
  onNavigate: (page: Page) => void;
}

const adminLinks: { label: string; page: Page; icon: ReactNode }[] = [
  { label: 'Tableau de Bord', page: 'admin', icon: <LayoutDashboard size={16} /> },
  { label: 'Matchs', page: 'admin-matchs', icon: <Swords size={16} /> },
  { label: 'Joueurs / Équipes', page: 'admin-joueurs', icon: <Users size={16} /> },
  { label: 'Brackets', page: 'admin-brackets', icon: <GitBranch size={16} /> },
  { label: 'Annonces', page: 'admin-annonces', icon: <Megaphone size={16} /> },
  { label: 'Récompenses', page: 'recompenses', icon: <Trophy size={16} /> },
  { label: 'Paramètres', page: 'parametres', icon: <Settings size={16} /> },
];

export default function AdminLayout({ children, currentPage, onNavigate }: AdminLayoutProps) {
  const { profile, signOut } = useAuth();

  async function handleSignOut() {
    await signOut();
    onNavigate('home');
  }

  return (
    <div className="min-h-screen bg-ghost-black flex">
      {/* Sidebar */}
      <aside className="w-52 bg-ghost-dark border-r border-ghost-border flex flex-col shrink-0 fixed h-full z-40">
        <div className="p-4 border-b border-ghost-border flex items-center gap-2">
          <Logo onNavigate={onNavigate} size="sm" />
        </div>

        <div className="px-4 py-3 border-b border-ghost-border">
          <div className="flex items-center gap-2">
            <Shield size={14} className="text-ghost-red" />
            <span className="text-ghost-red font-barlow font-black text-xs uppercase tracking-widest">Admin Panel</span>
          </div>
          <p className="text-ghost-gray text-[10px] uppercase tracking-wider mt-1">
            {profile?.cod_username ?? 'Admin'}
          </p>
        </div>

        <nav className="flex-1 flex flex-col py-2 overflow-y-auto">
          {adminLinks.map(({ label, page, icon }) => (
            <button
              key={label}
              onClick={() => onNavigate(page)}
              className={currentPage === page ? 'sidebar-link-active' : 'sidebar-link'}
            >
              <span className={currentPage === page ? 'text-ghost-gold' : 'text-ghost-gray'}>
                {icon}
              </span>
              {label}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-ghost-border flex flex-col gap-2">
          <button
            onClick={() => onNavigate('dashboard')}
            className="sidebar-link w-full text-ghost-gray"
          >
            <LayoutDashboard size={16} />
            Espace Joueur
          </button>
          <button
            onClick={handleSignOut}
            className="sidebar-link w-full text-ghost-red hover:text-red-400 hover:bg-red-950/20"
          >
            <LogOut size={16} />
            Déconnexion
          </button>
        </div>
      </aside>

      <div className="flex-1 ml-52 flex flex-col min-h-screen">
        <header className="sticky top-0 z-30 bg-ghost-dark/95 backdrop-blur border-b border-ghost-border px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield size={14} className="text-ghost-red" />
            <span className="text-ghost-gray text-xs font-barlow uppercase tracking-widest">Ghost Cup Admin</span>
            <span className="text-ghost-border">/</span>
            <span className="text-white text-xs font-barlow font-bold uppercase tracking-widest">
              {adminLinks.find(l => l.page === currentPage)?.label ?? 'Tableau de Bord'}
            </span>
          </div>
          <div className="flex items-center gap-2 bg-ghost-red/10 border border-ghost-red/30 px-3 py-1">
            <Shield size={12} className="text-ghost-red" />
            <span className="text-ghost-red text-[10px] font-barlow font-bold uppercase tracking-wider">Mode Admin</span>
          </div>
        </header>

        <main className="flex-1 p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
