import { ReactNode } from 'react';
import {
  LayoutDashboard,
  Swords,
  Users,
  GitBranch,
  Bell,
  Settings,
  LogOut,
  Shield,
} from 'lucide-react';
import { Page } from '../types';
import { useAuth } from '../context/AuthContext';
import Logo from './Logo';

interface DashboardLayoutProps {
  children: ReactNode;
  currentPage: Page;
  onNavigate: (page: Page) => void;
}

const playerLinks: { label: string; page: Page; icon: ReactNode }[] = [
  { label: 'Dashboard', page: 'dashboard', icon: <LayoutDashboard size={16} /> },
  { label: 'Mes Matchs', page: 'mes-matchs', icon: <Swords size={16} /> },
  { label: "Mon Équipe", page: 'mon-equipe', icon: <Users size={16} /> },
  { label: 'Bracket', page: 'bracket', icon: <GitBranch size={16} /> },
  { label: 'Notifications', page: 'notifications', icon: <Bell size={16} /> },
  { label: 'Paramètres', page: 'parametres', icon: <Settings size={16} /> },
];

export default function DashboardLayout({ children, currentPage, onNavigate }: DashboardLayoutProps) {
  const { profile, signOut } = useAuth();

  async function handleSignOut() {
    await signOut();
    onNavigate('home');
  }

  return (
    <div className="min-h-screen bg-ghost-black flex">
      {/* Sidebar */}
      <aside className="w-52 bg-ghost-dark border-r border-ghost-border flex flex-col shrink-0 fixed h-full z-40">
        <div className="p-4 border-b border-ghost-border">
          <Logo onNavigate={onNavigate} size="sm" />
        </div>

        {/* User info */}
        <div className="px-4 py-4 border-b border-ghost-border">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-ghost-gold/20 border border-ghost-gold/40 flex items-center justify-center">
              <span className="text-ghost-gold font-barlow font-black text-xs">
                {profile?.cod_username?.[0]?.toUpperCase() ?? 'G'}
              </span>
            </div>
            <div className="overflow-hidden">
              <p className="text-white font-barlow font-bold text-xs uppercase truncate">
                {profile?.cod_username ?? 'Joueur'}
              </p>
              <p className="text-ghost-gray text-[10px] uppercase tracking-wider">
                {profile?.role === 'admin' ? 'Admin' : 'Joueur'}
              </p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 flex flex-col py-2 overflow-y-auto">
          {playerLinks.map(({ label, page, icon }) => (
            <button
              key={page}
              onClick={() => onNavigate(page)}
              className={currentPage === page ? 'sidebar-link-active' : 'sidebar-link'}
            >
              <span className={currentPage === page ? 'text-ghost-gold' : 'text-ghost-gray'}>
                {icon}
              </span>
              {label}
            </button>
          ))}

          {profile?.role === 'admin' && (
            <>
              <div className="mx-4 my-2 border-t border-ghost-border" />
              <button
                onClick={() => onNavigate('admin')}
                className={currentPage === 'admin' || currentPage.startsWith('admin') ? 'sidebar-link-active' : 'sidebar-link'}
              >
                <Shield size={16} className="text-ghost-red" />
                Admin Panel
              </button>
            </>
          )}
        </nav>

        {/* Sign out */}
        <div className="p-4 border-t border-ghost-border">
          <button
            onClick={handleSignOut}
            className="sidebar-link w-full text-ghost-red hover:text-red-400 hover:bg-red-950/20"
          >
            <LogOut size={16} />
            Déconnexion
          </button>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 ml-52 flex flex-col min-h-screen">
        {/* Top bar */}
        <header className="sticky top-0 z-30 bg-ghost-dark/95 backdrop-blur border-b border-ghost-border px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-ghost-gray text-xs font-barlow uppercase tracking-widest">Ghost Cup</span>
            <span className="text-ghost-border">/</span>
            <span className="text-white text-xs font-barlow font-bold uppercase tracking-widest">
              {playerLinks.find(l => l.page === currentPage)?.label ?? 'Dashboard'}
            </span>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={() => onNavigate('notifications')} className="relative text-ghost-gray hover:text-white transition-colors">
              <Bell size={18} />
            </button>
            <button onClick={() => onNavigate('parametres')} className="text-ghost-gray hover:text-white transition-colors">
              <Settings size={18} />
            </button>
          </div>
        </header>

        <main className="flex-1 p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
